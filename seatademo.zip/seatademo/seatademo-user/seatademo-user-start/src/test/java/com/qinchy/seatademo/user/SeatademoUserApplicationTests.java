package com.qinchy.seatademo.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatademoUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
