package com.qinchy.seatademostoragestart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatademoStorageStartApplicationTests {

    @Test
    void contextLoads() {
    }

}
