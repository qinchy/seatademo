package com.qinchy.seatademo.storage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatademoStorageApplicationTests {

    @Test
    void contextLoads() {
    }

}
