package com.qinchy.seatademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatademoApplicationTests {

    @Test
    void contextLoads() {
    }

}
