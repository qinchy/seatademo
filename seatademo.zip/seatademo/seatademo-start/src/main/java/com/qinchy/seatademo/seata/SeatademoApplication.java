package com.qinchy.seatademo.seata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeatademoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SeatademoApplication.class, args);
    }

}
